User Guide for Excel Filter and Group Tool

Overview

The Excel Filter and Group Tool is a GUI-based application that allows users to filter data from an Excel file and group it based on specified columns. Additionally, a merge function is available to combine two Excel files into one.

System Requirements

Python 3.8 or later

Required Libraries:

pandas

tkinter

openpyxl

Installation

Install Python from python.org.

Open a terminal or command prompt and install the required packages:

pip install pandas openpyxl

How to Use

Filtering and Grouping Data

Launch the Application:

Run excel_gen_filter_gen_1.py using Python:

python excel_gen_filter_gen_1.py

Select Input Excel File:

Click the Browse button next to “Input Excel File” and select an .xlsx file.

Select Output Excel File:

Click the Browse button next to “Output Excel File” and choose a save location.

Set Filter Criteria:

Enter the Column Name and the Filter Value.

Click Add Filter to add more filters.

Group Data:

Enter column names to group by and click Add Group Column.

Process Data:

Click Filter and Group to generate the filtered and grouped output.

Merging Excel Files

Open Merge Tool:

Click the Open Merge Tool button.

This opens the merge.py script.

Select Excel Files:

Click Browse to select the first and second Excel files.

Select Output File:

Click Browse to set the output file location.

Merge Files:

Click Merge Files to combine the data.

Troubleshooting

Error: Missing dependencies:

Run pip install pandas openpyxl to ensure all dependencies are installed.

Excel file not loading:

Ensure the file is in .xlsx format and not corrupted.

Support
import pandas as pd
import tkinter as tk
from tkinter import filedialog, messagebox, Toplevel, ttk
import subprocess
import openpyxl
import threading
from openpyxl.utils.dataframe import dataframe_to_rows
 
# Global variable for template file
template_file = None
 
# Function to create a loading window with a progress bar
def show_loading_window():
    loading_window = Toplevel(root)
    loading_window.title("Processing...")
    loading_window.geometry("350x120")
    loading_window.resizable(False, False)
 
    tk.Label(loading_window, text="Generating Excel File...\nPlease wait.", font=("Arial", 10)).pack(pady=10)
 
    progress_var = tk.DoubleVar()
    progress_bar = ttk.Progressbar(loading_window, variable=progress_var, maximum=100, length=300)
    progress_bar.pack(pady=10)
 
    return loading_window, progress_var, progress_bar
 
# Function to identify the header row dynamically
def identify_header_row(input_file):
    raw_df = pd.read_excel(input_file, engine='openpyxl', nrows=100, header=None)  # Read first 100 rows
 
    max_valid_count = 0
    header_row = 0
    threshold = 0.5  # At least 50% non-empty values to be a valid header
 
    for i in range(len(raw_df)):
        valid_count = raw_df.iloc[i].notna().sum()  # Count non-empty cells
        total_columns = len(raw_df.iloc[i])  # Total columns in row
 
        if valid_count / total_columns >= threshold:  # Check if valid cells meet threshold
            if valid_count > max_valid_count:
                max_valid_count = valid_count
                header_row = i
 
    return header_row
 
# Function to filter and group Excel data with progress tracking
def filter_and_group_excel(input_file, output_file, filter_criteria, loading_window, progress_var, progress_bar):
    try:
        if not template_file:
            loading_window.destroy()
            messagebox.showerror("Error", "Please select a template file.")
            return
 
        # Step 1: Identify the dynamic header row
        header_row = identify_header_row(input_file)
 
        # Step 2: Load the Excel file dynamically
        df = pd.read_excel(input_file, engine='openpyxl', header=header_row, dtype=str)
 
        # Step 3: Normalize column names (strip spaces, convert to lowercase)
        df.columns = df.columns.str.strip().str.lower()
 
        # Step 4: Apply strict filters dynamically
        condition = pd.Series(True, index=df.index)  # Start with all rows selected
        for column, value in filter_criteria.items():
            normalized_col = column.strip().lower()  # Normalize user input to match column names
           
            if normalized_col in df.columns:
                condition &= df[normalized_col].astype(str).str.strip().str.lower().str.contains(str(value).strip().lower(), na=False)  # Exact match
            else:
                print(f"Warning: Column '{column}' not found in the data")
 
        # Apply filtering
        df_filtered = df[condition]  
 
        if df_filtered.empty:
            loading_window.destroy()
            messagebox.showwarning("No Data", "No data found matching the filter criteria.")
            return
 
        # Step 5: Load the Excel template
        wb = openpyxl.load_workbook(template_file)
        ws = wb.active
 
        # Step 6: Convert DataFrame to Excel and write to the template
        for r_idx, row in enumerate(dataframe_to_rows(df_filtered, index=False, header=False), start=4):
            for c_idx, value in enumerate(row, start=1):
                ws.cell(row=r_idx, column=c_idx, value=value)
 
            # Update progress bar every 10 rows
            if r_idx % 10 == 0 or r_idx == len(df_filtered):
                progress_var.set((r_idx - 3) / len(df_filtered) * 100)
                progress_bar.update()
 
        # Step 7: Save the filtered data into the output file
        wb.save(output_file)
 
        # Step 8: Close the loading window
        loading_window.destroy()
 
        messagebox.showinfo("Success", "Filtered Excel file has been created successfully!")
 
    except Exception as e:
        loading_window.destroy()
        messagebox.showerror("Error", f"An error occurred: {e}")
 
 
# Function to browse for input file
def browse_input_file():
    filename = filedialog.askopenfilename(filetypes=[("Excel files", "*.xlsx")])
    input_file_entry.delete(0, tk.END)
    input_file_entry.insert(0, filename)
    # Generate output file name based on filter criteria
    filter_criteria = get_filter_criteria()
    filter_suffix = "_".join([f"{k}_{v}" for k, v in filter_criteria.items()])
    output_filename = filename.replace(".xlsx", f"_{filter_suffix}.xlsx")
    output_file_entry.delete(0, tk.END)
    output_file_entry.insert(0, output_filename)
 
# Function to get filter criteria
def get_filter_criteria():
    filter_criteria = {}
    seen_columns = set()
    for column_entry, value_entry in filter_rows:
        column = column_entry.get()
        value = value_entry.get()
        if column and value:
            if column in seen_columns:
                messagebox.showerror("Input Error", f"Duplicate filter criteria for column: {column}")
                return None
            seen_columns.add(column)
            filter_criteria[column] = value
    return filter_criteria
 
# Function to browse for output file
def browse_output_file():
    filename = filedialog.asksaveasfilename(defaultextension=".xlsx", filetypes=[("Excel files", "*.xlsx")])
    output_file_entry.delete(0, tk.END)
    output_file_entry.insert(0, filename)
 
# Function to browse for a template file
def browse_template_file():
    global template_file
    filename = filedialog.askopenfilename(filetypes=[("Excel files", "*.xlsx")])
    if filename:
        template_file = filename
        template_file_entry.delete(0, tk.END)
        template_file_entry.insert(0, filename)
 
# Function to add a new filter row
def add_filter_row():
    row = len(filter_rows) + 2
    column_entry = tk.Entry(filter_frame, width=25)
    column_entry.grid(row=row, column=0, padx=5, pady=2)
    value_entry = tk.Entry(filter_frame, width=25)
    value_entry.grid(row=row, column=1, padx=5, pady=2)
    filter_rows.append((column_entry, value_entry))
 
# Function to start filtering and grouping in a separate thread
def on_filter_and_group_click():
    input_file = input_file_entry.get()
    # Generate output file name based on filter criteria
    filter_criteria = get_filter_criteria()
    if filter_criteria is None:
        return  # Exit if there is a duplicate column error
    filter_suffix = "_".join([f"{k}_{v}" for k, v in filter_criteria.items()])
    output_file = input_file.replace(".xlsx", f"_{filter_suffix}.xlsx")
    output_file_entry.delete(0, tk.END)
    output_file_entry.insert(0, output_file)
   
    if not input_file or not output_file:
        messagebox.showwarning("Input Error", "Please specify both input and output files.")
        return
   
    # Show loading window
    loading_window, progress_var, progress_bar = show_loading_window()
 
    # Run the function in a separate thread to prevent UI freezing
    threading.Thread(target=filter_and_group_excel, args=(input_file, output_file, filter_criteria, loading_window, progress_var, progress_bar), daemon=True).start()

# Function to run merge.py
def run_merge_script():
    try:
        subprocess.run(["python", "merge.py"], check=True)
    except subprocess.CalledProcessError as e:
        messagebox.showerror("Error", f"An error occurred while running merge.py: {e}")
 
# Create the main window
root = tk.Tk()
root.title("Excel Filter and Group Tool")
 
# Input and output file selection
file_frame = tk.Frame(root)
file_frame.pack(padx=10, pady=10, fill="x")
 
# Input file
tk.Label(file_frame, text="Input Excel File:").grid(row=0, column=0, sticky="e", padx=5, pady=5)
input_file_entry = tk.Entry(file_frame, width=50)
input_file_entry.grid(row=0, column=1, padx=5, pady=5)
tk.Button(file_frame, text="Browse", command=browse_input_file).grid(row=0, column=2, padx=5, pady=5)
 
# Output file
tk.Label(file_frame, text="Output Excel File:").grid(row=1, column=0, sticky="e", padx=5, pady=5)
output_file_entry = tk.Entry(file_frame, width=50)
output_file_entry.grid(row=1, column=1, padx=5, pady=5)
tk.Button(file_frame, text="Browse", command=browse_output_file).grid(row=1, column=2, padx=5, pady=5)
 
# Template file
tk.Label(file_frame, text="Template Excel File:").grid(row=2, column=0, sticky="e", padx=5, pady=5)
template_file_entry = tk.Entry(file_frame, width=50)
template_file_entry.grid(row=2, column=1, padx=5, pady=5)
tk.Button(file_frame, text="Browse", command=browse_template_file).grid(row=2, column=2, padx=5, pady=5)
 
# Filters frame
filter_frame = tk.LabelFrame(root, text="Filter Criteria", padx=10, pady=10)
filter_frame.pack(padx=10, pady=10, fill="x")
 
# Filter headers
tk.Label(filter_frame, text="Column Name", width=25).grid(row=0, column=0, padx=5, pady=5)
tk.Label(filter_frame, text="Filter Value", width=25).grid(row=0, column=1, padx=5, pady=5)
 
# Initial filter row
filter_rows = []
add_filter_row()
 
# Add filter button
tk.Button(filter_frame, text="Add Filter", command=add_filter_row).grid(row=1, column=2, padx=5, pady=5)
 
# Action button
action_frame = tk.Frame(root)
action_frame.pack(pady=10)
 
tk.Button(action_frame, text="Filter and Group", command=on_filter_and_group_click).pack()

# Place the "Run Merge Script" button at the bottom left
tk.Button(root, text="Run Merge Script", command=run_merge_script).pack(side="bottom", anchor="w", padx=10, pady=10)
 
# Run the application
root.mainloop()
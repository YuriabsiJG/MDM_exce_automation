import tkinter as tk
from tkinter import filedialog, messagebox
import pandas as pd
import openpyxl
import threading
import os

def select_file(entry_widget):
    """Select a single file and update entry widget."""
    filename = filedialog.askopenfilename(filetypes=[("Excel files", "*.xlsx")])
    if filename:
        entry_widget.delete(0, tk.END)
        entry_widget.insert(0, filename)

def add_file():
    """Add multiple selected files to the listbox."""
    filenames = filedialog.askopenfilenames(filetypes=[("Excel files", "*.xlsx")])
    for filename in filenames:
        listbox_files.insert(tk.END, os.path.basename(filename))  # Show filename only
        file_paths.append(filename)  # Store full path

def remove_selected_files():
    """Remove selected files from the listbox and file_paths list."""
    selected_items = listbox_files.curselection()
    for index in reversed(selected_items):
        listbox_files.delete(index)
        del file_paths[index]

def select_save_file(entry_widget):
    """Select output filename."""
    filename = filedialog.asksaveasfilename(defaultextension=".xlsx", filetypes=[("Excel files", "*.xlsx")])
    if filename:
        entry_widget.delete(0, tk.END)
        entry_widget.insert(0, filename)

def merge_excel():
    """Merge multiple Excel files into a selected template on a single sheet while preserving formatting."""
    output_filename = entry_output.get()
    template_filename = entry_template.get()

    if not file_paths:
        messagebox.showerror("Error", "Please select at least one file to merge")
        return
    if not template_filename:
        messagebox.showerror("Error", "Please select a template file")
        return
    if not output_filename:
        output_filename = "merged_output.xlsx"

    def process_merge():
        try:
            # Show "Merging..." pop-up
            merging_popup = tk.Toplevel(top)
            merging_popup.title("Merging...")
            merging_popup.geometry("250x100")
            tk.Label(merging_popup, text="Merging... Please wait!", font=("Arial", 12)).pack(pady=20)
            merging_popup.update()

            # Load the template while preserving formatting
            template_wb = openpyxl.load_workbook(template_filename)
            template_ws = template_wb.active

            # Start merging data from row 4
            first_empty_row = 4  

            # Load and merge data from selected files
            for file in file_paths:
                df = pd.read_excel(file, engine="openpyxl")

                # Remove headers (take only data rows)
                df = df.iloc[1:].reset_index(drop=True)  

                # Find the first truly empty row in the template
                while any(template_ws.cell(row=first_empty_row, column=1).value is not None for _ in range(1, df.shape[1] + 1)):
                    first_empty_row += 1

                # Append data into the template starting from row 4
                for row_data in df.itertuples(index=False, name=None):
                    for col_idx, value in enumerate(row_data, start=1):
                        template_ws.cell(row=first_empty_row, column=col_idx, value=value)
                    first_empty_row += 1  # Move to the next row after inserting data

            # Save the merged file
            template_wb.save(output_filename)
            template_wb.close()

            merging_popup.destroy()
            messagebox.showinfo("Success", f"Merged file saved as {output_filename}")
        except Exception as e:
            merging_popup.destroy()
            messagebox.showerror("Error", f"An error occurred: {e}")

    threading.Thread(target=process_merge, daemon=True).start()

# Tkinter UI
top = tk.Tk()
top.title("Excel File Merger")
top.geometry("600x500")

file_paths = []  # Stores full file paths

tk.Label(top, text="Select Template File:").pack()
entry_template = tk.Entry(top, width=60)
entry_template.pack()
tk.Button(top, text="Browse", command=lambda: select_file(entry_template)).pack()

tk.Label(top, text="Select Excel Files (Multiple Allowed):").pack()
listbox_files = tk.Listbox(top, selectmode=tk.MULTIPLE, width=60, height=10)
listbox_files.pack()

frame_buttons = tk.Frame(top)
frame_buttons.pack()
tk.Button(frame_buttons, text="Add Files", command=add_file).pack(side=tk.LEFT, padx=5)
tk.Button(frame_buttons, text="Remove Selected", command=remove_selected_files).pack(side=tk.LEFT, padx=5)

tk.Label(top, text="Output Filename:").pack()
entry_output = tk.Entry(top, width=60)
entry_output.pack()
tk.Button(top, text="Browse", command=lambda: select_save_file(entry_output)).pack()

tk.Button(top, text="Merge Selected Files", command=merge_excel).pack(pady=10)

top.mainloop()
